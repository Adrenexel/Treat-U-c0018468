

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <?php include 'include/style.php';?>
    <?php include 'include/nav.php';?>
    <title>Settings</title>
    <!-- Add your stylesheets and scripts here -->
</head>
<body>
    <h1>Settings</h1>

    <?php if (isset($_GET['message'])) { ?>
        <p><?php echo $_GET['message']; ?></p>
    <?php } ?>
    
    <h2>Change Password</h2>
    <form method="post" action="settings_q.php">
        <label for="new_pass">New Password:</label>
        <br><input type="password" id="new_pass" name="new_pass" required></br>
        <br><input type="submit" name="change_pass" value="Change Password"></br>
    </form>

    <h2>Update Address</h2>
    <form method="post" action="settings_q.php">
        <label for="address_line1">Address Line 1:</label>
        <br><input type="text" id="address_line1" name="address_line1" value="<?php echo isset($user['address_line1']) ? $user['address_line1'] : ''; ?>"></br>

        <label for="city">City:</label>
        <br><input type="text" id="city" name="city" value="<?php echo isset($user['city']) ? $user['city'] : ''; ?>"></br>

        <label for="post_code">Postal Code:</label>
        <br><input type="text" id="post_code" name="post_code" value="<?php echo isset($user['post_code']) ? $user['post_code'] : ''; ?>"></br>

        <label for="county">County:</label>
        <br><input type="text" id="county" name="county" value="<?php echo isset($user['county']) ? $user['county'] : ''; ?>"></br>

        <br><input type="submit" name="update_address" value="Update Address">
    </form>

  <!-- Add the payment details form to the HTML -->

<div class="row">
    <div class="col-md-6 offset-md-3">
        <h2>Payment Details</h2>
        <form method="post" action="settings.php">
            <div class="form-group">
                <label for="auction_id">Auction ID</label>
                <input type="text" name="auction_id" id="auction_id" class="form-control" required>
            </div>
            <div class="form-group">
                <label for="card_number">Card Number</label>
                <input type="text" name="card_number" id="card_number" class="form-control" required>
            </div>
            <div class="form-group">
                <label for="expiration_date">Expiration Date</label>
                <input type="text" name="expiration_date" id="expiration_date" class="form-control" required>
            </div>
            <div class="form-group">
                <label for="cvv">CVV</label>
                <input type="text" name="cvv" id="cvv" class="form-control" required>
            </div>
            <div class="form-group">
                <button type="submit" name="update_payment" class="btn btn-primary">Update Payment Details</button>
            </div>
        </form>
    </div>
</div>


        <a href = profile.php >Back to Profile</a>
    </div>
<footer>
    <?php //include 'include/footer.php';?>  
</footer>
</body>

</html>