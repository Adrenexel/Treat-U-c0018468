<?php
session_start();
?>

<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="UTF-8">
	<title>About Us</title>
	<link href="https://fonts.googleapis.com/css2?family=Dubai+Medium&display=swap" rel="stylesheet">
    <?php include 'include/style.php';?>
    <?php include 'include/nav.php';?>
    <?php include 'include/adjust.php';?>
</head>
<body>
<header>
        <div class="nav-bar">
            <?php
            // Check if the user is logged in
            if (isset($_SESSION['id'])) {
                // User is logged in
                $id = $_SESSION['id'];
                echo '<a href="profile.php">Profile</a>';
            } else {
                // User is not logged in
                echo '<a href="login.php">Login/Register</a>';
            }
            ?>            
            <a href="contact_us.php">Contact Us</a> 
            <a class="active" href="about_us.php">About Us</a>
            <a href="search.php">Search</a>
            <a href="index.php">Home</a>
            <a class="split" href="index.php"><img style="height:90px; " src="images/treatu.jpg"></a> 
        </div>
    </header>
	<div class="container">
            <div class="content-wrap">

                <h1>About Us</h1>
                <p>Welcome to the Secure Online Auction System! We are a premier online auction platform that provides a secure and trustworthy environment for buying and selling a wide range of items.</p>

                <h2>Our Mission</h2>
                <p>Our mission is to connect buyers and sellers worldwide and facilitate seamless transactions through a robust and secure online auction system. We strive to offer a user-friendly experience, reliable customer support, and a wide selection of high-quality items.</p>

                <h2>How It Works</h2>
                <p>As a registered user, you can participate in exciting auctions, place bids on your favorite items, and win exclusive deals. Our system ensures fair and transparent bidding processes, and we enforce strict security measures to protect your personal information and prevent fraud.</p>

                <h2>Why Choose Us</h2>
                <ul>
                    <li>Wide Selection: Explore a diverse range of products across various categories.</li>
                    <li>Secure Transactions: Our platform employs advanced security measures to safeguard your transactions.</li>
                    <li>User Verification: We verify the identity of both buyers and sellers to ensure a trusted marketplace.</li>
                    <li>Responsive Support: Our dedicated support team is available to assist you with any inquiries or concerns.</li>
                    <li>Convenient Bidding: Place bids and manage auctions effortlessly through our intuitive interface.</li>
                </ul>

                <p>Join us today and experience the excitement of online auctions while enjoying the peace of mind that comes with a secure and reliable platform.</p>
                </section>
            </div>
    </div>

<footer>
    <?php// include 'include/footer.php';?>  
</footer>

</body>
</html>