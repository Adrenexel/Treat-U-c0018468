<!DOCTYPE html>
<?php 
//starting the session
session_start();
require_once 'connection.php';
$id = $_SESSION['admin_id'];
$auth_user = $connection->query("SELECT * FROM users WHERE id = '$id'");
$result = $connection->query("SELECT * FROM users");
$admins = $connection->query("SELECT * FROM admins WHERE id = '$id'");
$admins = $admins->fetch();
?>
<html>
    <?php include 'include/style.php';?>
    <?php include 'include/nav.php';?>	
<body>
<header>

<div class="nav-bar">
        <a href="logout.php">Logout</a>
        <a href="admin_settings.php">Settings</a>
        <a class="active" href="admin.php">Admin</a>
        <a href="index.php">Home</a>
        <a class="split" href="index.php"><img style="height:90px; " src="images/treatu.jpg"></a> 
</div>
</header>

<h1>Admin: <?php echo $admins['id']; ?></p></h1>
    <div class="profile-info" action="admin_eg.php">
            <p><strong>Email:</strong> <?php echo $admins['email']; ?></p>
            <p><strong>Phone:</strong> <?php echo $admins['phone_number']; ?></p>
        </div>

	<div class="container">	
		<section class="py-5 header">
			<div class="container py-4">
				<div class="row">
                    <?php include 'include/hotbar.php' ?><a class="active" href="admin.php" class="btn btn-secondary" >Users</a>
                    <?php include 'include/hotbar.php' ?><a href="admin_listings.php" class="btn btn-secondary" >Listings</a>
                    <?php include 'include/hotbar.php' ?><a href="create_admin.php" class="btn btn-secondary" >Create Admin +</a>
                    <?php include 'include/hotbar.php' ?><a href="create_user.php" class="btn btn-secondary" >Create User +</a>
                    <?php include 'include/hotbar.php' ?><a href="user_support.php" class="btn btn-secondary" >User Support</a>
                    <?php include 'include/hotbar.php' ?> <a href="ban_users.php" class="btn btn-secondary" >User Penalty</a>
                </div>

                <h2>Users</h2>
				<div class="row mt-4">
				<table class="table m-3 rounded bg-light shadow-lg" id="id" id="first_name" id="last_name" id="email"id="phone_number" id="verifiaction_code"  class="table table-striped" style="width:105%">
					<thead class="thead-dark">
						<tr>
						<th scope="col">ID:</th>
						<th scope="col">First Name:</th>
						<th scope="col">last Name:</th>
						<th scope="col">Email:</th>
						<th scope="col">Phone Number:</th>
                        <th scope="col">Verification Code:</th>
						<th style="text-align:right" scope="col" class="text-center">Actions:</th>
						</tr>
					</thead>
					<tbody>
					<?php while ($row = $result->fetch()) { ?>
						<tr>
						<td><?php echo $row['id']; ?></td>
						<td><?php echo $row['first_name']; ?></td>
						<td><?php echo $row['last_name']; ?></td>
						<td><?php echo $row['email']; ?></td>
						<td><?php echo $row['phone_number']; ?></td>
                        <td><?php echo $row['verification_code']; ?></td>
						<td class="text-center">
						<td style="text-align:left" class="text-center">
						<a href="delete_user.php?id=<?php echo $row['id']; ?>" class="btn btn-sm">
							<svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="currentColor" class="bi bi-trash" viewBox="0 0 16 16">
							<path d="M5.5 5.5A.5.5 0 0 1 6 6v6a.5.5 0 0 1-1 0V6a.5.5 0 0 1 .5-.5zm2.5 0a.5.5 0 0 1 .5.5v6a.5.5 0 0 1-1 0V6a.5.5 0 0 1 .5-.5zm3 .5a.5.5 0 0 0-1 0v6a.5.5 0 0 0 1 0V6z"></path>
							<path fill-rule="evenodd" d="M14.5 3a1 1 0 0 1-1 1H13v9a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2V4h-.5a1 1 0 0 1-1-1V2a1 1 0 0 1 1-1H6a1 1 0 0 1 1-1h2a1 1 0 0 1 1 1h3.5a1 1 0 0 1 1 1v1zM4.118 4 4 4.059V13a1 1 0 0 0 1 1h6a1 1 0 0 0 1-1V4.059L11.882 4H4.118zM2.5 3V2h11v1h-11z"></path>
						</svg>
						</a>

						</td>
						</tr>
					<?php } ?>
					</tbody>
				</table>

				</div>
			</div>
		</section>
	</div>

<script>
  $(document).ready(function () {
    $('#id').DataTable();
});
    </script>
	<footer>
    <?php include 'include/footer.php';?>  
</footer>
</body>
</html>