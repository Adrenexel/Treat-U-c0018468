<?php
// Start the session
session_start();

// Require the database connection
require 'connection.php';

// Check if the user is logged in
if (!isset($_SESSION['id'])) {
    // User is not logged in
    header('Location: login.php');
    exit();
}

// Check if the auction ID and bid amount are provided
if (isset($_POST['auction_id']) && isset($_POST['bid_amount'])) {
    $auctionId = $_POST['auction_id'];
    $bidAmount = $_POST['bid_amount'];
    $bidderId = $_SESSION['id'];

    // Retrieve the current highest bid for the auction
    $auctionQuery = "SELECT MAX(bid_amount) AS highest_bid FROM Bids WHERE auction_id = :auction_id";
    $stmt = $connection->prepare($auctionQuery);
    $stmt->bindParam(':auction_id', $auctionId);
    $stmt->execute();
    $result = $stmt->fetch(PDO::FETCH_ASSOC);
    $highestBid = $result['highest_bid'];

    // Check if the bid amount is greater than the current highest bid
    if ($bidAmount > $highestBid) {
        // Insert the new bid into the database
        $insertQuery = "INSERT INTO Bids (auction_id, bidder_id, bid_amount) VALUES (:auction_id, :bidder_id, :bid_amount)";
        $stmt = $connection->prepare($insertQuery);
        $stmt->bindParam(':auction_id', $auctionId);
        $stmt->bindParam(':bidder_id', $bidderId);
        $stmt->bindParam(':bid_amount', $bidAmount);
        $stmt->execute();

        // Update the highest bid in the Auctions table
        $updateQuery = "UPDATE Auctions SET highest_bid = :highest_bid WHERE id = :auction_id";
        $stmt = $connection->prepare($updateQuery);
        $stmt->bindParam(':highest_bid', $bidAmount);
        $stmt->bindParam(':auction_id', $auctionId);
        $stmt->execute();

        // Redirect the user to the auction details page
        header('Location: auction_detail.php?id=' . $auctionId);
        exit();
    } else {
        // The bid amount is not higher than the current highest bid
        header('Location: auction_detail.php?id=' . $auctionId);
        exit();
    }
} else {
    // Invalid request
    header('Location: index.php');
    exit();
}
?>
