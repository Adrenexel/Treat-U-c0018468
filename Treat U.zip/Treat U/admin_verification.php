<?php
// Require the database connection
require 'connection.php';

// Check if the admin's account is verified
if ($admin['is_verified'] != 1) {
    // Display the verification form
    if ($_SERVER['REQUEST_METHOD'] === 'POST') {
        // Process the verification form
        $verificationCode = $_POST['verification_code'];

        // Check if the verification code is correct
        if ($verificationCode === $admin['verification_code']) {
            // Update the admin's verification status in the database
            updateVerificationStatus($admin['id']);

            // Redirect back to the admin page
            header("Location: admin.php");
            exit;
        } else {
            // Incorrect verification code, display an error message
            echo "Incorrect verification code. Please try again.";
        }
    } else {
        // Display the verification form
        ?>
        <form method="POST" action="">
            <label for="verification_code">Verification Code:</label>
            <input type="text" name="verification_code" id="verification_code" required>
            <button type="submit">Verify</button>
        </form>
        <?php
    }
} else {
    // Admin account is already verified, redirect back to the admin page
    header("Location: admin.php");
    exit;
}

// Function to update the admin's verification status
function updateVerificationStatus($adminId)
{
    // Implement the logic to update the admin's verification status in the database

    // Example code:
    global $connection;

    // Update the admin's verification status to verified
    $updateQuery = "UPDATE Admins SET is_verified = 1 WHERE id = :admin_id";
    $updateStmt = $connection->prepare($updateQuery);
    $updateStmt->bindParam(':admin_id', $adminId);
    $updateStmt->execute();
}
?>