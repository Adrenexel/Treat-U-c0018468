<!DOCTYPE html>
<html>
<head>
	<title>Forgot Password</title>
    <?php include 'include/style.php';?>
</head>
<body>
	<h1>Forgot Password</h1>
	<form method="post" action="">
		<label for="first-name">First Name</label>
		<input type="text" id="first-name" name="first-name" required>

		<label for="last-name">Last Name</label>
		<input type="text" id="last-name" name="last-name" required>

		<label for="email">Email Address</label>
		<input type="text" id="email" name="email" required>

		<p><input type="submit" value="Recover Password"></p>
	</form>

</body>
</html>