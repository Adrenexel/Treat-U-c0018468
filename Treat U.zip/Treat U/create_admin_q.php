

<?php

        // Start the session
        session_start();

        include_once 'connection.php';

        // Include the PHPMailer library
        require 'vendor\autoload.php';
        require 'vendor\phpmailer\phpmailer\src\Exception.php';
        require 'vendor\phpmailer\phpmailer\src\PHPMailer.php';
        require 'vendor\phpmailer\phpmailer\src\SMTP.php';

        use PHPMailer\PHPMailer\PHPMailer;
        use PHPMailer\PHPMailer\SMTP;
        use PHPMailer\PHPMailer\Exception;
        use PHPMailer\PHPMailer\OAuth;
        use PHPMailer\PHPMailer\autoload;


        if (isset($_POST['register'])) {
		    $valid = true;

        $email = $_POST['email'];
        $phone_number = $_POST['phone_number'];
		$verification_code = $_POST['verification_code'];
 

		if (empty($email) || empty($phone_number)) {
			$valid = false;
			$msg = "Please fill all the fields";
			header("location: create_admin.php?msg=$msg");
			exit();
	  	}

        $randomNumber = rand(10,99);
        $id = $randomNumber;
        
        // Generate a verification code
        $verification_code = generateVerificationCode();
		
		// Insertion Query
        $query = "INSERT INTO `admins` (id, email, phone_number, verification_code) 
        VALUES(:id, :email, :phone_number, :verification_code)";

		$stmt = $connection->prepare($query);
		$stmt->bindParam(':id', $id);
        $stmt->bindParam(':email', $email);
		$stmt->bindParam(':phone_number', $phone_number);
        $stmt->bindParam(':verification_code', $verification_code);
        $stmt->execute();


        // Send verification email to the user
        sendEmail($email, $verification_code);
        exit;
    }

    // Helper function to generate a random verification code
    function generateVerificationCode()
    {
        return substr(md5(uniqid(rand(), true)), 0, 6);
    }

    function sendEmail($email, $verification_code)
    {
        $mail = new PHPMailer;
        $mail->isSMTP();
        $mail->SMTPDebug = SMTP::DEBUG_SERVER;  // Enable verbose debug output
        $mail->Debugoutput = function ($str, $level) {
            echo "Debug level $level; message: $str\n";
        };

        $mail->Host = 'smtp.gmail.com';
        $mail->SMTPSecure = 'tls';
        $mail->SMTPAutoTLS = false;
        $mail->Port = 587;
        $mail->SMTPAuth = true;
        $mail->Username = 'ptusermail@gmail.com';
        $mail->Password = 'yxemzojcldqqblyx';

        $mail->setFrom('ptusermail@gmail.com');
        $mail->addAddress($email);
        $mail->Subject = 'Treat U';
        $mail->Body = 'OTP: ' . $verification_code;

        if ($mail->send()) {
            //setting a success message.
			$msg = "admin account created successfully";
            //redirecting to the index.php 
			header("location: admin.php?msg=$msg");
        } else {
            echo 'Email could not be sent. Please try again.';
            echo 'Mailer Error: ' . $mail->ErrorInfo;
            echo '<p><a href="create_admin.php">Error creating user account</a></p>';       
         }

		}
?>

