

<?php
session_start();


        // Include the PHPMailer library
        require 'vendor\autoload.php';
        require 'vendor\phpmailer\phpmailer\src\Exception.php';
        require 'vendor\phpmailer\phpmailer\src\PHPMailer.php';
        require 'vendor\phpmailer\phpmailer\src\SMTP.php';

        use PHPMailer\PHPMailer\PHPMailer;
        use PHPMailer\PHPMailer\SMTP;
        use PHPMailer\PHPMailer\Exception;
        use PHPMailer\PHPMailer\OAuth;
        use PHPMailer\PHPMailer\autoload;
        
        if ($_SERVER['REQUEST_METHOD'] === 'POST') {
            // Check if the required fields are filled
            if (isset($_POST['email']) && isset($_POST['message'])) {
                // Get the form data
                $email = $_POST['email'];
                $orderNumber = $_POST['order_number'];
                $message = $_POST['message'];
        
                // Include the PHPMailer library
                require 'vendor/autoload.php';
        
                // Create a new PHPMailer instance
                $mailer = new PHPMailer(true);
        
                try {
                    // SMTP configuration
                    $mailer->isSMTP();
                    $mailer->Host = 'smtp.gmail.com'; // Replace with your SMTP host
                    $mailer->SMTPAuth = true;
                    $mailer->Username = 'ptusermail@gmail.com'; // Replace with your SMTP username
                    $mailer->Password = 'yxemzojcldqqblyx'; // Replace with your SMTP password
                    $mailer->SMTPSecure = 'tls';
                    $mailer->Port = 587;
        
                    // Sender and recipient
                    $mailer->setFrom($email);
                    $mailer->addAddress('ptusermail@gmail.com'); // Admin's email address
        
                    // Email content
                    $mailer->Subject = 'Contact Form Submission';
                    $mailer->Body = "Email: $email\nOrder Number: $orderNumber\nMessage:\n$message";
        
                    // Send the email
                    $mailer->send();
        
                    // Email sent successfully
                    $successMessage = 'Your message has been sent. We will get back to you soon.';
                    header('Location: contact_us.php');

                } catch (Exception $e) {
                    // Failed to send email
                    $errorMessage = 'Oops! An error occurred while sending your message. Please try again later.';
                    error_log('Email sending failed: ' . $mailer->ErrorInfo);
                }
            } else {
                // Required fields are not filled
                $errorMessage = 'Email and message fields are required.';
            }
        }
        ?>
        