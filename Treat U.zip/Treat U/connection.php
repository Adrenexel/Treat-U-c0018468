<!-- Purpose: connect to the database -->

<?php
	//check if the database file exists
	if(!is_file('database/treatu.db')){
		file_put_contents('database/treatu.db', null);
	}
	// database connection
	$connection = new PDO('sqlite:database/treatu.db');
	$connection->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);

?>
