<?php
	require_once 'connection.php';
	
	if(ISSET($_GET['id'])){ 
		$id = $_GET['id'];
		// Deletion Query
		$query = "DELETE FROM `users` WHERE id = :id";
		$stmt = $connection->prepare($query);
		$stmt->bindParam(':id', $id);
		$stmt->execute();
		// Check if the execution of query is success
		if($stmt->execute()){
			//setting a success message.
			$msg = "User Deleted Successfully";

			//redirecting to the index.php 
			header("location: admin.php?msg=$msg");
		}
	}
?>