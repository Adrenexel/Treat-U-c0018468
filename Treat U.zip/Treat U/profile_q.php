<?php
// Start the session
session_start();

// Check if the user is logged in
if (isset($_SESSION['id'])) {
    // SQLite database file path
    require_once 'connection.php'; // Connection to the database

    // Retrieve the user data from the database
    $query = "SELECT * FROM users WHERE id = :id";
    $stmt = $connection->prepare($query);
    $stmt->bindParam(':id', $_SESSION['id']);
    $stmt->execute();
    $user = $stmt->fetch(PDO::FETCH_ASSOC);

   // Retrieve the Auctions data from the database
$query = "SELECT * FROM Auctions WHERE seller_id = :seller_id";
$stmt = $connection->prepare($query);
$stmt->bindParam(':seller_id', $_SESSION['id']);
$stmt->execute();
$auctions = $stmt->fetchAll(PDO::FETCH_ASSOC);

// Retrieve the Bids data from the database
$query = "SELECT * FROM Bids WHERE bidder_id = :bidder_id";
$stmt = $connection->prepare($query);
$stmt->bindParam(':bidder_id', $_SESSION['id']);
$stmt->execute();
$bids = $stmt->fetchAll(PDO::FETCH_ASSOC);

// Retrieve the address data from the database
$query = "SELECT * FROM address WHERE user_id = :user_id";
$stmt = $connection->prepare($query);
$stmt->bindParam(':user_id', $_SESSION['id']);
$stmt->execute();
$address = $stmt->fetch(PDO::FETCH_ASSOC);

    // Check if a user with the given ID exists
    if (!$user) {
        // Handle the case when the user does not exist
        // For example, redirect to an error page or display an error message
        // You can customize this based on your requirements
        die("User not found");
    }
} else {
    // Handle the case when the user is not logged in
    // For example, redirect to the login page
    header('Location: login.php');
    exit;
}
?>
