    
        <!DOCTYPE html>
        <html>
        <head>
            <title>Contact Us</title>
            <?php include 'include/style.php' ?>
            <?php include 'include/nav.php' ?>
        </head>
        <body>
            <header>
                <div class="nav-bar">
                    <?php
                    // Check if the user is logged in
                    if (isset($_SESSION['id'])) {
                        // User is logged in
                        $id = $_SESSION['id'];
                        echo '<a href="profile.php">Profile</a>';
                    } else {
                        // User is not logged in
                        echo '<a href="login.php">Login/Register</a>';
                    }
                    ?>            
                    <a class="active" href="contact_eg.php">Contact Us</a> 
                    <a href="about_us.php">About Us</a>
                    <a href="search.php">Search</a>
                    <a href="index.php">Home</a>
                    <a class="split" href="index.php"><img style="height:90px; " src="images/treatu.jpg"></a> 
                </div>
            </header>
        
            <div class="container">
                <section class="contact-section">
                    <h1>Contact Us</h1>
                    <p>Have a question or need assistance? Fill out the form below, and we'll get back to you as soon as possible.</p>
        
                    <div class="contact-form">
                        <?php if (isset($errorMessage)) { ?>
                            <p class="error"><?php echo $errorMessage; ?></p>
                        <?php } ?>
        
                        <?php if (isset($successMessage)) { ?>
                            <p class="success"><?php echo $successMessage; ?></p>
                        <?php } ?>
        
                        <form method="post" action="contact_us_q.php">
                            <label for="email">Email</label>
                            <input type="text" id="email" name="email" required>
        
                            <label for="order_number">Order Number:</label>
                            <input type="text" id="order_number" name="order_number">
        
                            <label for="message">Message:</label>
                            <textarea id="text" name="message" required></textarea>
        
                            <p><input type="submit" value="Send"></p>
                        </form>
                    </div>
                </section>
            </div>
        
            <footer>
                <?php include 'include/footer.php';?>  
            </footer>
        </body>
        </html>
        