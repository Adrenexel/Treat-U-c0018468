<!DOCTYPE html>
<?php 
//starting the session
session_start();
require_once 'connection.php';
$id = $_GET['id'];
$auth_user = $connection->query("SELECT * FROM users WHERE id = '$id'");
$result = $connection->query("SELECT * FROM users");
?>
<html>
<head>
    <meta charset="utf-8">
    <?php include 'include/style.php';?>
    <?php include 'include/nav.php';?>
    <title>Delete User</title>
<body>
<header>
<div class="about-section">
        <div class="inner-width">
          <h1 class="n">Are you sure want to delete this user?</h1>
          <div class="bord"></div>
          <div class="about-section-row">
            <div class="about-section-col">
              <div class="about">
                <p>
                     Once you deleted the user,  you can't restore the account. You must re-register the user again.
                </p>

            </div>
            <div class="btu">
            <form action = "admin.php">
                <button class="b"><?php include 'include/hotbar.php' ?><a>Back</a> </button>
            </form>
            <form action = "delete_user_q.php?" method = "get">
                <button class="d">  <?php include 'include/hotbar.php' ?><a>Delete</a> </button>
                <input type="hidden" name = "id" value = "<?php echo $id ?>">
            </form>
</div>
            </div>
         
</header>
<footer>
    <?php include 'include/footer.php';?>  
</footer>
</body>
</html> 
		