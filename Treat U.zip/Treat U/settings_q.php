<?php
// Start the session
session_start();

// Check if the user is logged in
if (!isset($_SESSION['id'])) {
    // Redirect to the login page if the user is not logged in
    header("Location: login.php");
    exit;
}

// Include the database connection and other necessary files
include_once 'connection.php';

// Get the user ID from the session
$user_id = $_SESSION['id'];

// Retrieve the user's information from the database
$select_query = "SELECT * FROM users WHERE id = :id";
$stmt = $connection->prepare($select_query);
$stmt->bindParam(':id', $user_id);
$stmt->execute();
$user = $stmt->fetch(PDO::FETCH_ASSOC);

// Check if the form is submitted for changing the password
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['change_pass'])) {
    // Get the new password from the form
    $new_pass = $_POST['new_pass'];

    // Hash the new password
    $hashed_pass = password_hash($new_pass, PASSWORD_DEFAULT);

    // Update the user's password in the database
    $update_query = "UPDATE users SET password = :password WHERE id = :id";
    $stmt = $connection->prepare($update_query);
    $stmt->bindParam(':password', $hashed_pass);
    $stmt->bindParam(':id', $user_id);
    $stmt->execute();

    // Redirect to the settings page with a success message
    header("Location: login.php");
    exit;
}

// Check if the form is submitted for updating the address
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['update_address'])) {
    // Get the address information from the form
    $address_line1 = $_POST['address_line1'];
    $city = $_POST['city'];
    $post_code = $_POST['post_code'];
    $county = $_POST['county'];
    $user_id = $_SESSION['id'];

    // Check if the user has an existing address
    $select_query = "SELECT * FROM address WHERE user_id = :user_id";
    $stmt = $connection->prepare($select_query);
    $stmt->bindParam(':user_id', $user_id);
    $stmt->execute();
    $existing_address = $stmt->fetch(PDO::FETCH_ASSOC);

    if ($existing_address) {
        // Update the user's existing address in the database
        $update_query = "UPDATE address SET address_line1 = :address_line1, city = :city, post_code = :post_code, county = :county WHERE user_id = :user_id";
        $stmt = $connection->prepare($update_query);
        $stmt->bindParam(':address_line1', $address_line1);
        $stmt->bindParam(':city', $city);
        $stmt->bindParam(':post_code', $post_code);
        $stmt->bindParam(':county', $county);
        $stmt->bindParam(':user_id', $user_id);
        $stmt->execute();
    } else {
        // Insert a new address for the user
        $insert_query = "INSERT INTO address (user_id, address_line1, city, post_code, county) VALUES (:user_id, :address_line1, :city, :post_code, :county)";
        $stmt = $connection->prepare($insert_query);
        $stmt->bindParam(':user_id', $user_id);
        $stmt->bindParam(':address_line1', $address_line1);
        $stmt->bindParam(':city', $city);
        $stmt->bindParam(':post_code', $post_code);
        $stmt->bindParam(':county', $county);
        $stmt->execute();
    }

    // Redirect or display a success message
    header("Location: profile.php");
    exit;
}

// Check if the form is submitted for updating the payment details
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['update_payment'])) {
    // Get the payment details from the form
    $user_id = $_SESSION['id'];
    $card_number = $_POST['card_number'];
    $expiration_date = $_POST['expiration_date'];
    $cvv = $_POST['cvv'];

    // Insert or update the payment details in the database
    $select_query = "SELECT * FROM Payments WHERE user_id = :user_id";
    $stmt = $connection->prepare($select_query);
    $stmt->bindParam(':user_id', $user_id);
    $stmt->execute();
    $existing_payment = $stmt->fetch(PDO::FETCH_ASSOC);

    if ($existing_payment) {
        // Update the existing payment details in the database
        $update_query = "UPDATE Payments SET card_number = :card_number, expiration_date = :expiration_date, cvv = :cvv WHERE user_id = :user_id";
        $stmt = $connection->prepare($update_query);
        $stmt->bindParam(':card_number', $card_number);
        $stmt->bindParam(':expiration_date', $expiration_date);
        $stmt->bindParam(':cvv', $cvv);
        $stmt->bindParam(':user_id', $user_id);
        $stmt->execute();
    } else {
        // Insert a new payment record in the database
        $insert_query = "INSERT INTO Payments (user_id, card_number, expiration_date, cvv) VALUES (:user_id, :card_number, :expiration_date, :cvv)";
        $stmt = $connection->prepare($insert_query);
        $stmt->bindParam(':user_id', $user_id);
        $stmt->bindParam(':card_number', $card_number);
        $stmt->bindParam(':expiration_date', $expiration_date);
        $stmt->bindParam(':cvv', $cvv);
        $stmt->execute();
    }

    // Redirect or display a success message
    header("Location: settings.php");
    exit;
}
?>