<?php
    // Start the session
    session_start();

    include_once 'connection.php';

    // Check if the user is logged in as an admin
    require_once 'connection.php';
    $id = $_SESSION['admin_id'];

    // Check if a user ID is provided in the query string
    if (isset($_GET['user_id'])) {
        $user_id = $_GET['user_id'];

        // Check if the user exists in the database
        $query = "SELECT * FROM `users` WHERE `id` = :user_id";
        $stmt = $connection->prepare($query);
        $stmt->bindParam(':user_id', $user_id);
        $stmt->execute();
        $user = $stmt->fetch(PDO::FETCH_ASSOC);

        if (!$user) {
            echo "User not found";
            exit();
        }

        // Check if the user has already been banned
        $query = "SELECT * FROM `penalty` WHERE `user_id` = :user_id";
        $stmt = $connection->prepare($query);
        $stmt->bindParam(':user_id', $user_id);
        $stmt->execute();
        $penalty = $stmt->fetch(PDO::FETCH_ASSOC);

        if ($penalty) {
            echo "User already banned";
            exit();
        }

        // Add the user to the penalty table with 1 point
        $query = "INSERT INTO `penalty` (user_id, points) VALUES (:user_id, 1)";
        $stmt = $connection->prepare($query);
        $stmt->bindParam(':user_id', $user_id);
        $stmt->execute();

        echo "User banned successfully";
    }

    // Get all users and their penalty points
    $query = "SELECT u.*, p.points FROM `users` u LEFT JOIN `penalty` p ON u.id = p.user_id";
    $stmt = $connection->prepare($query);
    $stmt->execute();
    $users = $stmt->fetchAll(PDO::FETCH_ASSOC);
?>

<!DOCTYPE html>
<html>
    <?php include 'include/style.php';?>
    <?php include 'include/nav.php';?>	
<body>
<header>

<div class="nav-bar">
        <a href="logout.php">Logout</a>
        <a href="admin_settings.php">Settings</a>
        <a class="active" href="admin.php">Admin</a>
        <a href="index.php">Home</a>
        <a class="split" href="index.php"><img style="height:90px; " src="images/treatu.jpg"></a> 
</div>
</header>
<body>
<div class="container">	
		<section class="py-5 header">
			<div class="container py-4">
				<div class="row">
                    <?php include 'include/hotbar.php' ?><a href="admin.php" class="btn btn-secondary" >Users</a>
                    <?php include 'include/hotbar.php' ?><a href="admin_listings.php" class="btn btn-secondary" >Listings</a>
                    <?php include 'include/hotbar.php' ?><a href="create_admin.php" class="btn btn-secondary" >Create Admin +</a>
                    <?php include 'include/hotbar.php' ?><a href="create_user.php" class="btn btn-secondary" >Create User +</a>
                    <?php include 'include/hotbar.php' ?><a href="user_support.php" class="btn btn-secondary" >User Support</a>
                    <?php include 'include/hotbar.php' ?> <a class="active" href="ban_users.php" class="btn btn-secondary" >User Penalty</a>
                </div>

    <h1>Ban Users</h1>
    <table>
        <tr>
            <th>User ID</th>
            <th>First Name</th>
            <th>Last Name</th>
            <th>Email</th>
            <th>Phone Number</th>
            <th>Penalty Points</th>
            <th>Action</th>
        </tr>
        <?php foreach ($users as $user) { ?>
            <tr>
                <td><?php echo $user['id']; ?></td>
                <td><?php echo $user['first_name']; ?></td>
                <td><?php echo $user['last_name']; ?></td>
                <td><?php echo $user['email']; ?></td>
                <td><?php echo $user['phone_number']; ?></td>
                <td><?php echo $user['points'] ?? 0; ?></td>
                <td>
                    <?php if ($user['points'] >= 3) { ?>
                        User Banned
                    <?php } else { ?>
                        <a href="ban_users.php?user_id=<?php echo $user['id']; ?>">Ban User</a>
                    <?php } ?>
                </td>
            </tr>
        <?php } ?>
    </table>
 </div>
 </div>

    <footer>
    <?php include 'include/footer.php';?>  
</footer>
</body>
</html>
