<!DOCTYPE html>
<?php
// Start the session
session_start();

// Require the database connection
require 'connection.php';

// Retrieve active auction listings
$sql = "SELECT * FROM Auctions WHERE end_time > CURRENT_TIMESTAMP";
$stmt = $connection->prepare($sql);
$stmt->execute();
$auctions = $stmt->fetchAll(PDO::FETCH_ASSOC);
?>
<html lang="en">
<head>
    <meta charset="UTF-8">
	<title>Home</title>
    <?php include 'include/style.php';?>
    <?php include 'include/nav.php';?>
    <style>
        .auction-listing {
            width: 25%;
            padding: 10px;
            box-sizing: border-box;
            float: left;
            margin-top: 50px; /* Add desired top margin */
        }

        .auction-listing img {
            width: 200px; /* Adjust the width as desired */
            height: auto; /* This ensures the height is adjusted proportionally */
            max-width: 100%; /* Prevent images from exceeding their container */
        }
    </style>
</head>
<body>
    <header>
        <div class="nav-bar">
            <?php
            // Check if the user is logged in
            if (isset($_SESSION['id'])) {
                // User is logged in
                $id = $_SESSION['id'];
                echo '<a href="profile.php">Profile</a>';
                echo '<a href="logout.php">Logout</a>';
            } else {
                // User is not logged in
                echo '<a href="login.php">Login/Register</a>';
            }
            ?>            
            <a href="contact_us.php">Contact Us</a> 
            <a href="about_us.php">About Us</a>
            <a href="search.php">Search</a>
            <a class="active" href="index.php">Home</a>
            <a class="split" href="index.php"><img style="height:90px; " src="images/treatu.jpg"></a> 
        </div>
    </header>

    <div class="auction-listings">
        <?php
        // Check if there are active auction listings
        if (count($auctions) > 0) {
            foreach ($auctions as $auction) {
                $auctionId = $auction['id'];
                $image = '<img src="auction_ads/' . $auction['image'] . '">';
                $title = $auction['title'];
                $description = $auction['description'];
                $startingPrice = $auction['starting_price'];

                // Generate HTML to display the auction listing
                echo '<div class="auction-listing">';
                echo '<div>'. $image . '</div>';
                echo '<h3>' . $title . '</h3>';
                echo '<p>' . $description . '</p>';
                echo '<p>Starting Price: $' . $startingPrice . '</p>';
                echo '<a href="auction_detail.php?id=' . $auctionId . '">View Details</a>';
                echo '</div>';
            }
        } else {
            echo '<p>No active auction listings available.</p>';
        }
        ?>
    </div>

    <footer>
        <?php include 'include/footer.php';?>  
    </footer>
</body>
</html>
