<style>
*{
  padding:0px;
  margin:0px;
}
#aligner {
  position: absolute;
  bottom: 25;
  width: 100%;
  text-align: center;
}

footer{
  position: absolute;
  bottom: 0;
  width: 100%;
  height: 2.5rem;            /* Footer height */
}

  </style>

<div>
<div id="aligner" style="background-color:#333; padding:13px;">
<span class="rights-text" style="text-align:center; font-weight:bold; font-size:13px; color:white;">
Contact us through our <a href = "contact_us.php">'Contact Page'</a></span><br>
</div>