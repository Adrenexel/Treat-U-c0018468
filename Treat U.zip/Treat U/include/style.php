<style>
    
.container {
    margin: 0 auto;
    max-width: 800px;
    padding: 20px;
    text-align: center;
    min-height: 100vh;
    padding-bottom: 80px;
}


h1 {
    font-size: 35px;
    margin: 32px auto;
    text-align: center;
    color: #1F1E1C;
}

h2 {
    font-size: 25px;
    margin: 32px auto;
    text-align: center;
    color: #1F1E1C;
}

h3 {
    font-size: 20px;
    margin: 1px auto;
    text-align: center;
    color: #1F1E1C;
}

li {
    font-size: 15px;
    margin: 15px auto;
    text-align: center;
    color: #1F1E1C;
}

body {
    background-color: #EEEAFB;
    color: white;
    font-family: 'Dubai Medium', sans-serif;
    font-size: 15px;
    text-align: center;
}

p {
    color: #1F1E1C; 
    text-align: center;
}

th{
    color: #1F1E1C;
    text-align: center;
    font-family: 'Dubai Medium', sans-serif; 
    font-size: 15px;
}

td{
    color: #1F1E1C;
    text-align: center;
    font-family: 'Dubai Medium', sans-serif;
    font-size: 10px;
}
        
form {
       background-color: #1F1E1C;
       text-align: center;
       list-style: none;
       color: white;
       font-family: 'Dubai Medium';
       font-size: 90%;
       padding: 10px;
       margin: 1px 1px 1px 1px;
       border: 3px solid #C0A4FB;
}


label {
    display: block;
	  margin: 10px auto;
	  text-align: center;
	  width: 300px;
}

.number{
    display: block;
    margin: 10px auto;
    text-align: center;
    width: 600px;
}

.addy{
    font-family: 'Dubai Medium';
    background-color: #C0A4FB;
    margin: 10px auto;
    text-align: center;
    width: 600px;
    font-size: 10px;
}

.footer {
  position: absolute;
  right: 0;
  bottom: 0;
  left: 0;
  padding: 1rem;
  background-color: #efefef;
  text-align: center;
}

input[type=text], input[type=password] {
  	background-color: #EEEAFB;
  	border: none;
  	color: #1F1E1C;
    font-family: 'Dubai Medium';
  	font-size: 15px;
  	height: 28px;
  	margin: 10px auto;
    opacity: 0.6;
  	padding: 0;
  	text-align: center;
  	width: 300px;
}

input[type=submit] {
	background-color: #EEEAFB;
	border-color: #C0A4FB;
	color: #1F1E1C;
	cursor: pointer;
	font-family: 'Dubai Medium';
	font-size: 20px;
	font-weight: bold;
	height: 40px;
	margin: 20px auto;
	outline: none;
	transition: background-image 0.2s;
	width: 300px;
}

input[type=submit]:hover {
	background-image: #EEEAFB;
}
</style>