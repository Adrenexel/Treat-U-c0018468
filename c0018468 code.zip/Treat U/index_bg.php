<!DOCTYPE html>
<?php

// Require the database connection
require 'connection.php';

// Retrieve active auction listings
$sql = "SELECT * FROM Auctions WHERE end_time > CURRENT_TIMESTAMP";
$stmt = $connection->prepare($sql);
$stmt->execute();
$auctions = $stmt->fetchAll(PDO::FETCH_ASSOC);
?>
<html lang="en">
<head>
    <meta charset="UTF-8">
	<title>Home</title>
    <?php include 'include/style.php';?>
    <?php include 'include/nav.php';?>
    <style>
        .auction-listing {
            width: 25%;
            padding: 10px;
            box-sizing: border-box;
            float: left;
            margin-top: 50px; /* Add desired top margin */
        }

        .auction-listing img {
            width: 200px; /* Adjust the width as desired */
            height: auto; /* This ensures the height is adjusted proportionally */
            max-width: 100%; /* Prevent images from exceeding their container */
        }
    </style>
</head>
<body>

    <div class="auction-listings">
        <?php
        // Check if there are active auction listings
        if (count($auctions) > 0) {
            foreach ($auctions as $auction) {
                $auctionId = $auction['id'];
                $image = '<img src="auction_ads/' . $auction['image'] . '">';
                $title = $auction['title'];
                $description = $auction['description'];
                $startingPrice = $auction['starting_price'];

                // Generate HTML to display the auction listing
                echo '<div class="auction-listing">';
                echo '<div>'. $image . '</div>';
                echo '<h3>' . $title . '</h3>';
                echo '<p>' . $description . '</p>';
                echo '<p>Starting Price: $' . $startingPrice . '</p>';
                echo '<a href="auction_detail.php?id=' . $auctionId . '">View Details</a>';
                echo '</div>';
            }
        } else {
            echo '<p>No active auction listings available.</p>';
        }
        ?>
    </div>


</body>
</html>
