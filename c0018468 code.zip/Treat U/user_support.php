

<?php
// Start the session and include necessary files
session_start();
include_once 'connection.php';

// Retrieve the user support queries from the database
$select_query = "SELECT * FROM UserSupport ORDER BY created_at DESC";
$stmt = $connection->prepare($select_query);
$stmt->execute();
$user_queries = $stmt->fetchAll(PDO::FETCH_ASSOC);

$id = $_SESSION['admin_id'];
$admins = $connection->query("SELECT * FROM admins WHERE id = '$id'");
$admins = $admins->fetch();
?>

<!DOCTYPE html>
<html>
<head>
    <meta charset="utf-8">
    <?php include 'include/style.php';?>
    <?php include 'include/nav.php';?>
  <title>User Support</title>
  <style>
    table {
      border-collapse: collapse;
      width: 100%;
    }
    
    th, td {
      padding: 8px;
      text-align: left;
      border-bottom: 1px solid #ddd;
    }
  
    .checkmark {
      display: inline-block;
      width: 16px;
      height: 16px;
      border-radius: 50%;
      vertical-align: middle;
    }
    .checkmark-green {
      background-color: #00ff00;
    }
    .checkmark-red {
      background-color: #ff0000;
    }
  </style>
</head>
<header>
        <div class="nav-bar">
            <a href="logout.php">Logout</a>
            <a href="settings.php">Settings</a>
            <a href="auctions.php">List</a>
            <a class="active" href="profile.php">Profile</a>
            <a href="contact_us.php">Contact Us</a> 
            <a href="about_us.php">About Us</a>
            <a href="search.php">Search</a>
            <a href="index.php">Home</a>
            <a class="split" href="index.php"><img style="height:90px; " src="images/treatu.jpg"></a> 
        </div>
    </header>
<body>

<h1>Admin: <?php echo $admins['id']; ?></p></h1>
    <div class="profile-info" action="admin.php">
            <p><strong>Email:</strong> <?php echo $admins['email']; ?></p>
            <p><strong>Phone:</strong> <?php echo $admins['phone_number']; ?></p>
        </div>

<div class="container">	
		<section class="py-5 header">
			<div class="container py-4">
				<div class="row">
                    <?php include 'include/hotbar.php' ?><a href="admin.php" class="btn btn-secondary" >Users</a>
                    <?php include 'include/hotbar.php' ?><a href="admin_listings.php" class="btn btn-secondary" >Listings</a>
                    <?php include 'include/hotbar.php' ?><a href="create_admin.php" class="btn btn-secondary" >Create Admin +</a>
                    <?php include 'include/hotbar.php' ?><a href="create_user.php" class="btn btn-secondary" >Create User +</a>
                    <?php include 'include/hotbar.php' ?><a class="active" href="user_support.php" class="btn btn-secondary" >User Support</a>
                    <?php include 'include/hotbar.php' ?> <a href="ban_users.php" class="btn btn-secondary" >User Penalty</a>
                </div>

  <h2>User Support</h2>

  <table>
    <thead>
      <tr>
        <th>ID</th>
        <th>Email</th>
        <th>Order Number</th>
        <th>Message</th>
        <th>Date & Time</th>
        <th>Reply</th>
        <th>Responded</th>
      </tr>
    </thead>
    <tbody>
      <?php foreach ($user_queries as $query) : ?>
        <tr>
          <td><?= $query['id'] ?></td>
          <td><?= $query['email'] ?></td>
          <td><?= $query['order_number'] ?></td>
          <td><?= $query['query'] ?></td>
          <td><?= $query['created_at'] ?></td>
          <td><a href="reply.php?id=<?= $query['id'] ?>">Reply</a></td>
          <td>
                  <?php if ($query['reply']) : ?>
                    <span class="checkmark checkmark-green"></span>
                  <?php else : ?>
                    <span class="checkmark checkmark-red"></span>
                  <?php endif; ?>
                </td>
        </tr>
      <?php endforeach; ?>
    </tbody>
  </table>

</body>
</html>


