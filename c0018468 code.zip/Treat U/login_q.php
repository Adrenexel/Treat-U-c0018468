<?php
// Start the session
session_start();

include_once 'connection.php';

ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);


// Check if the form is submitted
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // Get the form data
    $email = $_POST['email'];
    $password_or_code = $_POST['password_or_code'];

    // Validate the form data (e.g., check for empty fields)

    // Retrieve the user from the database based on the email
    $user_query = "SELECT * FROM users WHERE email = :email";
    $stmt = $connection->prepare($user_query);
    $stmt->bindParam(':email', $email);
    $stmt->execute();

    $user = $stmt->fetch(PDO::FETCH_ASSOC);

    // Retrieve the admin from the database based on the email
    $admin_query = "SELECT * FROM admins WHERE email = :email";
    $stmt = $connection->prepare($admin_query);
    $stmt->bindParam(':email', $email);
    $stmt->execute();

    $admin = $stmt->fetch(PDO::FETCH_ASSOC);

    // Verify the password or verification code for users
    if ($user) {
        $is_password_matched = password_verify($password_or_code, $user['password']);
        $is_code_matched = isset($user['verification_code']) && $password_or_code === $user['verification_code'];

        if ($is_password_matched || $is_code_matched) {
            // Password or verification code is correct for users, set session variables
            $_SESSION['id'] = $user['id'];
            // Redirect the user to the desired page
            header('Location: index.php');
            exit;
        }
    }

    // Verify the password or verification code for admins
    if ($admin) {
        $is_password_matched = password_verify($password_or_code, $admin['password']);
        $is_code_matched = isset($admin['verification_code']) && $password_or_code === $admin['verification_code'];

        if ($is_password_matched || $is_code_matched) {
            // Password or verification code is correct for admins, set session variables
            $_SESSION['admin_id'] = $admin['id'];
            // Redirect the admin to the desired page
            header('Location: admin.php');
            exit;
        }
    }

    // Invalid email, password, or verification code
    $error = "Invalid email, password, or verification code";
    // Redirect to the login page with an error message
    header("location:login.php?error=" . urlencode($error));
    exit;
}

// Close the database connection
$pdo = null;
?>