<?php
session_start();

// Require the database connection
require 'connection.php';

// Include the PHPMailer library
require 'vendor/autoload.php';
require 'vendor/phpmailer/phpmailer/src/Exception.php';
require 'vendor/phpmailer/phpmailer/src/PHPMailer.php';
require 'vendor/phpmailer/phpmailer/src/SMTP.php';

use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\SMTP;
use PHPMailer\PHPMailer\Exception;
use PHPMailer\PHPMailer\OAuth;
use PHPMailer\PHPMailer\autoload;

// Check if the form is submitted
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // Check if the required fields are filled
    if (isset($_POST['email']) && isset($_POST['message'])) {
        // Get the form data
        $email = $_POST['email'];
        $orderNumber = $_POST['order_number'];
        $message = $_POST['message'];

        // Insert the user support query into the database
        $insertQuery = "INSERT INTO UserSupport (email, order_number, query) VALUES (:email, :order_number, :query)";
        $stmt = $connection->prepare($insertQuery);
        $stmt->bindParam(':email', $email);
        $stmt->bindParam(':order_number', $orderNumber);
        $stmt->bindParam(':query', $message);
        $stmt->execute();

        // Create a new PHPMailer instance
        $mailer = new PHPMailer(true);

        try {
            // SMTP configuration
            $mailer->isSMTP();
            $mailer->Host = 'smtp.gmail.com'; // Replace with your SMTP host
            $mailer->SMTPAuth = true;
            $mailer->Username = 'ptusermail@gmail.com'; // Replace with your SMTP username
            $mailer->Password = 'yxemzojcldqqblyx'; // Replace with your SMTP password
            $mailer->SMTPSecure = 'tls';
            $mailer->Port = 587;

            // Sender and recipient
            $mailer->setFrom($email);
            $mailer->addAddress('ptusermail@gmail.com'); // Admin's email address

            // Email content
            $mailer->Subject = 'Treat U Messages';
            $mailer->Body = "Email: $email\nOrder Number: $orderNumber\nMessage:\n$message";

            // Send the email
            $mailer->send();

            // Email sent successfully
            $_SESSION['successMessage'] = 'Your message has been sent. We will get back to you soon.';
            header('Location: contact_us.php');
            exit();
        } catch (Exception $e) {
            // Failed to send email
            $errorMessage = 'Oops! An error occurred while sending your message. Please try again later.';
            error_log('Email sending failed: ' . $mailer->ErrorInfo);
        }
    } else {
        // Required fields are not filled
        $errorMessage = 'Email and message fields are required.';
    }
}
?>
