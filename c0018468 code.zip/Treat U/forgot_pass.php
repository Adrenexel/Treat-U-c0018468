<!DOCTYPE html>
<html>
<head>
	<title>Forgot Password</title>
    <?php include 'include/style.php';?>
</head>
<body>
	<h1>Forgot Password</h1>
	<form method="post" action="forgot_pass_q.php">
		<label for="first-name">First Name</label>
		<input type="text" id="first-name" name="first-name" required>

		<label for="last-name">Last Name</label>
		<input type="text" id="last-name" name="last-name" required>

		<label for="email">Email Address</label>
		<input type="text" id="email" name="email" required>

		<p><input type="submit" value="Recover Password"></p>
	</form>
	
	<p>Dont have an account? <a href="register.php">Sign up now</a>.</p>
	<p>Remember your account password? <a href="login.php">Login now</a>.</p>
    <p><a href="login.php">Back</a>.</p>

</body>
</html>