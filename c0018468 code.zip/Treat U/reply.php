
<!DOCTYPE html>
<html>
<head>
    <meta charset="utf-8">
    <?php include 'include/style.php'; ?>
    <?php include 'include/nav.php'; ?>
    <?php require_once 'reply_q.php'; ?>
    <title>Reply to User Query</title>
</head>
<body>
    <header>
                <div class="nav-bar">
                    <a href="logout.php">Logout</a>
                    <a href="admin_settings.php">Settings</a>
                    <a class="active" href="admin.php">Admin</a>
                    <a href="index.php">Home</a>
                    <a class="split" href="index.php"><img style="height:90px; " src="images/treatu.jpg"></a> 
                 </div>
</header>
    </header>

    <div class="container">
        <h2>Reply to: <ul><i><?php echo $query['email']; ?></ul></i></h2>
        <form method="post">
            <div class="form-group">
                <label for="email">User Email</label>
                <input type="text" id="email" name="email" value="<?php echo $query['email']; ?>" disabled>
            </div>
            <div class="form-group">
                <label for="order_number">Order Number</label>
                <input type="text" id="order_number" name="order_number" value="<?php echo $query['order_number']; ?>" disabled>
            </div>
            <div class="form-group">
                <label for="message">User Query</label>
                <textarea id="message" name="message" rows="4" disabled><?php echo $query['query']; ?></textarea>
            </div>
            <div class="form-group">
                <label for="reply">Admin Reply</label>
                <textarea id="reply" name="reply" rows="4" required></textarea>
            </div>
            <div class="form-group">
                 <p><input type="submit" value="Send"></p>
            </div>
        </form>
        <a href="user_support.php">Back</a>
    </div>
</body>
</html>
