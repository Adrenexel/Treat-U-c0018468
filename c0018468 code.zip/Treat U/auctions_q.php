<?php
// Start the session
session_start();

// Check if the user is logged in
if (isset($_SESSION['id'])) {
    // SQLite database file path
    require_once 'connection.php'; // Connection to the database

    if ($_SERVER['REQUEST_METHOD'] == 'POST') {
        $id = $_SESSION['id'];
        $title = $_POST['title'];
        $description = $_POST['description'];
        $starting_price = $_POST['starting_price'];
        $end_time = $_POST['end_time'];

        // Get the image details
        $image_name = $_FILES['image']['name'];
        $image_tmp = $_FILES['image']['tmp_name'];
        $image_type = $_FILES['image']['type'];

        // Generate a unique file name
        $extension = pathinfo($image_name, PATHINFO_EXTENSION);
        $file_name = uniqid() . '.' . $extension;

        // Set the upload path
        $upload_path = 'uploads/' . $file_name;

        // Move the uploaded file to the specified path
        move_uploaded_file($image_tmp, $upload_path);

        // Insert the auction listing into the database
        $sql = "INSERT INTO Auctions (seller_id, title, description, starting_price, end_time, image) VALUES (?, ?, ?, ?, ?, ?)";
        $stmt = $connection->prepare($sql);
        $stmt->execute([$id, $title, $description, $starting_price, $end_time, $file_name]);

        $auction_id = $connection->lastInsertId();

        header("Location: index.php");
        exit();
    }
}
?>
