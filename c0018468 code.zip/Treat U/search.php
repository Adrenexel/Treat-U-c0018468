
<?php
include_once 'connection.php';

// Get search keyword from form submission
if (isset($_POST['search'])) {
  $keyword = $_POST['keyword'];
} else {
  $keyword = '';
}

// Search for user profiles and posts based on keyword
$stmt = $connection->prepare("
  SELECT users.email, users.first_name, users.last_name, auctions.title, auctions.description
  FROM users
  LEFT JOIN auctions ON users.id = auctions.user_id
  WHERE users.id LIKE :keyword OR users.first_name LIKE :keyword OR users.last_name LIKE :keyword OR auctions.title LIKE :keyword OR auctions.description LIKE :keyword
");
$stmt->execute(['keyword' => "%$keyword%"]);
$results = $stmt->fetchAll(PDO::FETCH_ASSOC);
?>

<!DOCTYPE html>
<html>
<head>
  <title>Search</title>
  <?php include 'include/style.php'; ?>
  <?php include 'include/nav.php'; ?>
</head>
<header>
        <div class="nav-bar">
            <?php
            // Check if the user is logged in
            if (isset($_SESSION['id'])) {
                // User is logged in
                $id = $_SESSION['id'];
                echo '<a href="profile.php">Profile</a>';
                echo '<a href="logout.php">Logout</a>';
            } else {
                // User is not logged in
                echo '<a href="login.php">Login/Register</a>';
            }
            ?>            
            <a href="contact_us.php">Contact Us</a> 
            <a href="about_us.php">About Us</a>
            <a class="active" href="search.php">Search</a>
            <a href="index.php">Home</a>
            <a class="split" href="index.php"><img style="height:90px; " src="images/treatu.jpg"></a> 
        </div>
    </header>
<body>
  <div class="container">
    <div class="row">
      <div class="col-md-6 offset-md-3">
        <h2>Search Results</h2>

        <!-- Search form -->
        <form method="post" action="search.php">
          <div class="input-group mb-3">
            <input type="text" name="keyword" class="form-control" placeholder="Search for users or auction listings" value="<?= $keyword ?>">
            <div class="input-group-append">
              <button type="submit" name="search" class="btn btn-primary">Search</button>
            </div>
          </div>
        </form>

        <!-- Display search results -->
        <?php if (!empty($results)) : ?>
          <ul class="list-group list-unstyled">
            <?php foreach ($results as $result) : ?>
              <li class="list-group-item">
                <?php if (isset($result['title'])) : ?>
                  <!-- Display post result -->
                  <a href="auctions.php?title=<?= $result['title'] ?>">
                    <img src="auction_ads/<?= $result['title'] ?>.jpg" alt="<?= $result['title'] ?>" class="mr-3" style="width:64px;height:64px;">
                    <?= $result['title'] ?>
                  </a>
                <?php elseif (isset($result['email'])) : ?>
                  <!-- Display user profile result -->
                  <a href="profile.php?email=<?= $result['email'] ?>">
                    <?= $result['email'] ?>
                  </a>
                <?php endif; ?>
              </li>
            <?php endforeach; ?>
          </ul>
        <?php elseif (isset($_POST['search'])) : ?>
          <!-- No search results found -->
          <p>No results found for "<?= $keyword ?>".</p>
        <?php endif; ?>
      </div>
    </div>
  </div>

  <p><a href="index.php">Back</a></p>

  <div>
  <div id="index_bg.php">
		<?php include('index_bg.php'); ?>
	</div>
	<style>
	#index{
		position: fixed;
		width: 100%;
		height: 50%;
		bottom: 0;
		background-color: #0c0d13;
		z-index: 1;
		filter: blur(100px);
    opacity: 100;
	}
	</style>
</body>
</html>

