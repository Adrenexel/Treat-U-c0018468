

<!DOCTYPE html>
<?php require_once 'profile_q.php'; ?>

<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Profile</title>
    <?php include 'include/style.php'; ?>
    <?php include 'include/nav.php'; ?>
</head>
<body>
    <header>
        <div class="nav-bar">
            <a href="logout.php">Logout</a>
            <a href="settings.php">Settings</a>
            <a href="auctions.php">List</a>
            <a class="active" href="profile.php">Profile</a>
            <a href="contact_us.php">Contact Us</a> 
            <a href="about_us.php">About Us</a>
            <a href="search.php">Search</a>
            <a href="index.php">Home</a>
            <a class="split" href="index.php"><img style="height:90px; " src="images/treatu.jpg"></a> 
        </div>
    </header>
    <div class="container">
        <h1>Profile</h1>
            <div class="profile-info">
                <p><strong>Name:</strong> <?php echo $user['first_name']; ?></p>
                <p><strong>Last Name:</strong> <?php echo $user['last_name']; ?></p>
                <p><strong>Email:</strong> <?php echo $user['email']; ?></p>
                <p><strong>Phone:</strong> <?php echo $user['phone_number']; ?></p>
            </div>
            <div class="addy">
                <h3>Address</h3>
                <div class="profile-info">
            <?php if ($address) : ?>
                <p><strong>Address Line 1:</strong> <?php echo $address['address_line1']; ?></p>
                <p><strong>City:</strong> <?php echo $address['city']; ?></p>
                <p><strong>Post Code:</strong> <?php echo $address['post_code']; ?></p>
                <p><strong>County:</strong> <?php echo $address['county']; ?></p>
            <?php else : ?>
                <p>Set address through settings</p>
            <?php endif; ?>
        </div>
    </div>

        <h2>Auction Listings</h2>
            <div class="profile-info">
                <?php if (isset($auctions) && !empty($auctions)) : ?>
                    <table>
                        <tr>
                            <th>Title</th>
                            <th>Description</th>
                            <th>Start Price</th>
                            <th>End Time</th>
                            <th>Action</th>
                        </tr>
                        <?php foreach ($auctions as $auction) : ?>
                            <tr>
                                <td><a href="auction_detail.php?id=<?php echo $auction['id']; ?>"><?php echo $auction['title']; ?></a></td>
                                <td><?php echo $auction['description']; ?></td>
                                <td><?php echo $auction['starting_price']; ?></td>
                                <td><?php echo $auction['end_time']; ?></td>
                                <td><a href="delete_my_listing.php?id=<?php echo $auction['id']; ?>">Delete</a></td>
                            </tr>
                        <?php endforeach; ?>
                    </table>
                <?php else : ?>
                    <p>No auction listings found.</p>
                <?php endif; ?>
            </div>

            <h2>Bidding History</h2>
                <div class="profile-info">
                    <?php if (isset($bids) && !empty($bids)) : ?>
                        <table>
                            <tr>
                                <th>Auction ID</th>
                                <th>Title</th>
                                <th>Seller ID</th>
                                <th>Seller Email</th>
                                <th>Bid</th>
                                <th>Bid Time</th>
                            </tr>
                            <?php foreach ($bids as $bid) : ?>
                                <?php
                                $query = "SELECT Auctions.title, Auctions.seller_id, Users.email 
                                        FROM Auctions 
                                        INNER JOIN Users ON Auctions.seller_id = Users.id 
                                        WHERE Auctions.id = :auction_id";
                                $stmt = $connection->prepare($query);
                                $stmt->bindParam(':auction_id', $bid['auction_id']);
                                $stmt->execute();
                                $auctionInfo = $stmt->fetch(PDO::FETCH_ASSOC);
                                ?>
                                <tr>
                                    <td><?php echo $bid['auction_id']; ?></td>
                                    <td><?php echo $auctionInfo['title']; ?></td>
                                    <td><?php echo $auctionInfo['seller_id']; ?></td>
                                    <td><?php echo $auctionInfo['email']; ?></td>
                                    <td>£<?php echo $bid['bid_amount']; ?></td>
                                    <td><?php echo $bid['bid_time']; ?></td>
                                </tr>
                            <?php endforeach; ?>
                        </table>
                    <?php else : ?>
                        <p>No bidding history found.</p>
                    <?php endif; ?>
                </div>
            </div>
        <footer>
            <?php include 'include/footer.php';?>  
        </footer>
    </div>
</body>
</html>
