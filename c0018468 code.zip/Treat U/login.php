
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Login</title>
    <?php include 'include/style.php';?>
</head>
<body>
<div class="login-form">
    <?php if (isset($_GET['error'])) { ?>
        <p><?php echo urldecode($_GET['error']); ?></p>
    <?php } ?>
    <div class="container">
        <h1>Login</h1>
        <form method="post" action="login_q.php">
            <label for="email">Email</label>
            <input type="text" id="email" name="email" required>

            <label for="password_or_code">Password or Verification Code:</label>
            <input type="password" id="password_or_code" name="password_or_code" required>

            <p><input type="submit" value="Sign In"></p>
        </form>

        <p>Don't have an account? <a href="register.php">Register now</a>.</p>
        <p>Forgot your password? <a href="forgot_pass.php">Click here</a>.</p>
    </div>
</div>

<p> <a href="index.php">Back</a></p>

<footer>
    <?php include 'include/footer.php';?>
</footer>
</body>
</html>