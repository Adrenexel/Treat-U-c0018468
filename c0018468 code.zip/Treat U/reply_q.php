<?php
session_start();

// Require the database connection
require 'connection.php';

// Include the PHPMailer library
require 'vendor/autoload.php';
require 'vendor/phpmailer/phpmailer/src/Exception.php';
require 'vendor/phpmailer/phpmailer/src/PHPMailer.php';
require 'vendor/phpmailer/phpmailer/src/SMTP.php';

use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\SMTP;
use PHPMailer\PHPMailer\Exception;
use PHPMailer\PHPMailer\OAuth;
use PHPMailer\PHPMailer\autoload;

// Check if the user is logged in as admin
if (!isset($_SESSION['admin_id'])) {
    header('Location: login.php');
    exit();
}

// Check if the query ID is provided
if (!isset($_GET['id'])) {
    header('Location: user_support.php');
    exit();
}

$queryId = $_GET['id'];

// Retrieve the user query from the database
$selectQuery = "SELECT * FROM UserSupport WHERE id = :query_id";
$stmt = $connection->prepare($selectQuery);
$stmt->bindParam(':query_id', $queryId);
$stmt->execute();
$query = $stmt->fetch(PDO::FETCH_ASSOC);

// Check if the query exists
if (!$query) {
    header('Location: user_support.php');
    exit();
}

// Check if the form is submitted
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // Check if the required fields are filled
    if (isset($_POST['reply'])) {
        // Get the form data
        $reply = $_POST['reply'];

        // Update the query with the admin's reply
        $updateQuery = "UPDATE UserSupport SET reply = :reply WHERE id = :query_id";
        $stmt = $connection->prepare($updateQuery);
        $stmt->bindParam(':reply', $reply);
        $stmt->bindParam(':query_id', $queryId);
        $stmt->execute();

        // Send email to the user with the admin's reply
        try {
            $mailer = new PHPMailer(true);

            // SMTP configuration
            $mailer->isSMTP();
            $mailer->Host = 'smtp.gmail.com'; // Replace with your SMTP host
            $mailer->SMTPAuth = true;
            $mailer->Username = 'ptusermail@gmail.com'; // Replace with your SMTP username
            $mailer->Password = 'yxemzojcldqqblyx'; // Replace with your SMTP password
            $mailer->SMTPSecure = 'tls';
            $mailer->Port = 587;

            // Sender and recipient
            $mailer->setFrom('ptusermail@gmail.com');
            $mailer->addAddress($query['email']); // User's email address

            // Email content
            $mailer->Subject = 'Reply to Your Query';
            $mailer->Body = "Dear User,\n\nYou have received a reply to your query. Here is the admin's response:\n\n$reply\n\nThank you for contacting us.\n\nBest regards,\nTreat U Support";

            // Send the email
            $mailer->send();

            $_SESSION['successMessage'] = 'Reply sent successfully.';
            header('Location: user_support.php');
            exit();
        } catch (Exception $e) {
            $_SESSION['errorMessage'] = 'Oops! An error occurred while sending the reply. Please try again later.';
            error_log('Email sending failed: ' . $mailer->ErrorInfo);
        }
    }
}
?>
