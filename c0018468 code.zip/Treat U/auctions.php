<!DOCTYPE html>

<html>
<head>
    <meta charset="utf-8">
    <?php include 'include/style.php';?>
    <title>Create Auction Listing</title>
</head>
<body>
    <h1>Create Auction Listing</h1>
    <form method="post" action="auctions_q.php" enctype="multipart/form-data">
        <label for="title">Title</label>
        <input type="text" id="title" name="title" required>
        <br>
        <label for="description">Description</label>
        <textarea id="description" name="description" required></textarea>
        <br>
        <label for="image">Picture</label>
        <input type="file" id="image" name="image" required>
        <br>
        <label for="starting_price">Starting Price</label>
        <input type="number" id="starting_price" name="starting_price" step="0.01" required>
        <br>
        <label for="end_time">Time Limit</label>
        <input type="datetime-local" id="end_time" name="end_time" required>
        <br>
        <input type="hidden" name="user_id" value="<?php echo $_SESSION['id']; ?>">
        <br>
        <input type="submit" value="Create Listing">
    </form>
    <a href = profile.php >Back to Profile</a>
    <footer>
    <?php include 'include/footer.php';?>  
</footer>
</body>
</html>