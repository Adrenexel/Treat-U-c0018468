<?php
// Start session and connect to database
session_start();
require_once('connection.php');

$id = $_SESSION['admin_id'];

// Fetch admin details
$stmt = $connection->prepare("SELECT * FROM admins WHERE id = :adminId");
$stmt->execute(['adminId' => $adminId]);
$admin = $stmt->fetch(PDO::FETCH_ASSOC);
$admins = $connection->query("SELECT * FROM admins WHERE id = '$id'");
$admins = $admins->fetch();

// Update admin password
if (isset($_POST['update_password'])) {
  $currentPassword = $_POST['current_password'];
  $newPassword = $_POST['new_password'];
  $confirmPassword = $_POST['confirm_password'];

  // Verify current password
  if (password_verify($currentPassword, $admin['password'])) {
    // Check if new password matches the confirmation
    if ($newPassword === $confirmPassword) {
      // Hash the new password
      $hashedPassword = password_hash($newPassword, PASSWORD_DEFAULT);

      // Update admin password in the database
      $stmt = $connection->prepare("UPDATE admins SET password = :password WHERE id = :adminId");
      $stmt->execute(['password' => $hashedPassword, 'adminId' => $adminId]);

      // Redirect to admin dashboard or login page
      header("Location: admin_dashboard.php");
      exit();
    } else {
      $error = "New password and confirm password do not match.";
    }
  } else {
    $error = "Invalid current password.";
  }
}
?>

<!DOCTYPE html>
<html>
<head>
  <title>Admin Settings</title>
  <?php include 'include/style.php'; ?>
  <?php include 'include/nav.php'; ?>
</head>
<body>
  <div class="container">
    <div class="row">
      <div class="col-md-6 offset-md-3">
        <h2>Admin Settings</h2>

        <form method="post" action="admin_settings.php">
          <div class="form-group">
            <label for="current_password">Current Password:</label>
            <input type="password" name="current_password" id="current_password" class="form-control" required>
          </div>
          <div class="form-group">
            <label for="new_password">New Password:</label>
            <input type="password" name="new_password" id="new_password" class="form-control" required>
          </div>
          <div class="form-group">
            <label for="confirm_password">Confirm Password:</label>
            <input type="password" name="confirm_password" id="confirm_password" class="form-control" required>
          </div>
          <button type="submit" name="update_password" class="btn btn-primary">Update Password</button>
        </form>

        <?php if (isset($error)) : ?>
          <div class="alert alert-danger mt-3"><?php echo $error; ?></div>
        <?php endif; ?>

      </div>
      <a href = admin.php >Back to Profile</a>

    </div>
  </div>
  
  <footer>
      <?php include 'include/footer.php'; ?>
  </footer>
</body>
</html>
