
<?php
// Start the session
session_start();

// Require the database connection
require 'connection.php';

$userId = isset($_SESSION['id']) ? $_SESSION['id'] : null;

// Check if auction ID is provided
if (isset($_GET['id'])) {
    $auctionId = $_GET['id'];

    $auctionEnded = false;
    $loggedIn = isset($_SESSION['id']);


    // Retrieve auction details
    $auctionQuery = "SELECT Auctions.*, Users.first_name, Users.last_name, Users.email, MAX(Bids.bid_amount) AS highest_bid
    FROM Auctions
    INNER JOIN Users ON Auctions.seller_id = Users.id
    LEFT JOIN Bids ON Auctions.id = Bids.auction_id
    WHERE Auctions.id = :auction_id
    GROUP BY Auctions.id";

    $stmt = $connection->prepare($auctionQuery);
    $stmt->bindParam(':auction_id', $auctionId);
    $stmt->execute();
    $auction = $stmt->fetch(PDO::FETCH_ASSOC);

    // Check if auction exists
    if ($auction) {
        $auctionId = $auction['id'];
        $title = $auction['title'];
        $description = $auction['description'];
        $startingPrice = $auction['starting_price'];
        $endTime = $auction['end_time'];
        $sellerId = $auction['seller_id'];
        $highestBid = $auction['highest_bid'];


        // Check if the user is logged in
        if (isset($_SESSION['id'])) {
            $userId = $_SESSION['id'];


} else {
    echo '<p>Please log in to place a bid.</p>';
}

    } else {
        echo '<p>Auction not found.</p>';
    }
} else {
    echo '<p>Invalid auction ID.</p>';
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Auction Details</title>
    <?php include 'include/style.php';?>
    <?php include 'include/nav.php';?>
</head>
<body>
    <header>
        <div class="nav-bar">
            <?php
            // Check if the user is logged in
            if (isset($_SESSION['id'])) {
                // User is logged in
                $id = $_SESSION['id'];
                echo '<a href="profile.php">Profile</a>';
                echo '<a href="logout.php">Logout</a>';
            } else {
                // User is not logged in
                echo '<a href="login.php">Login/Register</a>';
            }
            ?>
            <a href="contact_eg.php">Contact Us</a> 
            <a href="about_us.php">About Us</a>
            <a href="search.php">Search</a>
            <a class="active" href="index.php">Home</a>
            <a class="split" href="index.php"><img style="height:90px; " src="images/treatu.jpg"></a> 
        </div>
    </header>

    <div class="container">

    <div class="auction-details">
        <h1><?php echo $auction['title']; ?></h1>
        <div class="auction-image">
            <img src="uploads/<?php echo $auction['image']; ?>" alt="Auction Image" style="max-width: 100%; max-height: 200px;">
        </div>


        <div class="auction-info">
            <p>Description: <?php echo $auction['description']; ?></p>
            <p>Starting Price: £<?php echo $auction['starting_price']; ?></p>
            <p>Highest Bid: £<?php echo $auction['highest_bid']; ?></p>
            <p>End Time: <?php echo $auction['end_time']; ?></p>
            <p>Seller ID: <?php echo $auction['seller_id']; ?></p>
            <p><?php echo '<p>Seller: ' . $auction['first_name'] . ' ' . $auction['last_name'] . '</p>'; ?></p>
            <p><?php echo '<p>Seller Email: ' . $auction['email'] . '</p>'; ?></p>
        </div>

            <?php
                        // Check if the user is logged in
                        if ($userId) {
                            // Check if the user is the seller
                            if ($userId == $sellerId) {
                                echo '<p>You are the seller of this auction.</p>';
                            } else {
                            // Display bid forms
                            echo '<form method="post" action="bid.php">';
                            echo '<input type="hidden" name="auction_id" value="' . $auctionId . '">';
                            echo '<input type="hidden" name="bidder_id" value="' . $userId . '">';
                            echo '<label for="bid_amount">Bid Amount:</label>';
                            echo '<input type="number" id="bid_amount" name="bid_amount" step="0.01" required>';
                            echo "<br>";
                            echo '<input type="submit" value="Place Bid">';
                            echo '</form>';
                            }
                        }
            ?>
            <?php if ($auctionEnded) : ?>
                <p>This auction has ended.</p>
            <?php elseif (!$loggedIn) : ?>
                <p>Please <a href="login.php">login</a> to place a bid on this item.</p>
                <?php if (isset($bidCount) && $bidCount > 0) : ?>
                <p>You have already placed a bid on this item.</p>
            <?php else : ?>
                <form method="post" action="bid.php">
                    <input type="hidden" name="auction_id" value="<?php echo $auctionId; ?>">
                    <input type="hidden" name="bidder_id" value="<?php echo $userId; ?>">
                    <br><label for="bid_amount">Bid Amount:</label></br>
                    <br><input type="number" step="0.01" min="<?php echo $auction['starting_price']; ?>" id="bid_amount" name="bid_amount" required></br>
                    <br><input type="submit" value="Place Bid"></br>
                </form>
            <?php endif; ?>
            <?php endif; ?>
    </div>
    </div>
</div>

      <a href="index.php">Back to Home</a>

    <footer>
        <?php //include 'include/footer.php';?>  
    </footer>
</body>
</html>

