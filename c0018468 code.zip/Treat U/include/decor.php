<style>
img{

    height: 200px;
}