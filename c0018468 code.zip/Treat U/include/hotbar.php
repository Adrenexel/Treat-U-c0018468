<style>
 a{
padding: 20px; 
color: #1F1E1C; 
text-align: center; 
background-color: #C0A4FB; 
margin: 1px 1px 1px 1px; 
display:inline-block; 
line-height:1px;"
}

a:hover {
  color: #C0A4FB;
  background-color: #1F1E1C;
}

.active {
  color: #C0A4FB;
  background-color: #1F1E1C;
}
</style>