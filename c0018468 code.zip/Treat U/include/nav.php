<nav>
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
<style>

*{
  padding:0px;
  margin:0px;
}
.nav-bar {
  position: top;
  overflow: hidden;
  background-color: #C0A4FB;
}

.nav-bar a {
  float: right;
  color: #EEEAFB;
  text-align: center;
  padding: 14px 16px;
  text-decoration: none;
  font-size: 17px;
}

.nav-bar a.split {
  float: left;
  padding: 0px 0px;
}

.nav-bar a:hover {
  color: #C0A4FB;
  background-color: #1F1E1C;
}

.active {
  color: #1F1E1C;
  background-color: #1F1E1C;
}

.img-container {
    text-align: center; 
}

</style>

</nav>