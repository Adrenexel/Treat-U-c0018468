<!DOCTYPE html>
<?php 
//starting the session
session_start();
require_once 'connection.php';
$id = $_SESSION['admin_id'];
$auth_user = $connection->query("SELECT * FROM Auctions WHERE id = '$id'");
$result = $connection->query("SELECT * FROM Auctions");
$admins = $connection->query("SELECT * FROM admins WHERE id = '$id'");
$admins = $admins->fetch();
?>
<html>
    <?php include 'include/style.php';?>
    <?php include 'include/nav.php';?>	
<body>
<header>

<div class="nav-bar">
        <a href="logout.php">Logout</a>
        <a href="admin_settings.php">Settings</a>
        <a class="active" href="admin.php">Admin</a>
        <a href="index.php">Home</a>
        <a class="split" href="index.php"><img style="height:90px; " src="images/treatu.jpg"></a> 
</div>
</header>

<h1>Admin: <?php echo $admins['id']; ?></p></h1>
    <div class="profile-info" action="admin.php">
            <p><strong>Email:</strong> <?php echo $admins['email']; ?></p>
            <p><strong>Phone:</strong> <?php echo $admins['phone_number']; ?></p>
        </div>

	<div class="container">	
		<section class="py-5 header">
			<div class="container py-4">
				<div class="row">
                    <?php include 'include/hotbar.php' ?><a href="admin.php" class="btn btn-secondary" >Users</a>
                    <?php include 'include/hotbar.php' ?><a class="active" href="admin_listings.php" class="btn btn-secondary" >Listings</a>
                    <?php include 'include/hotbar.php' ?><a href="create_admin.php" class="btn btn-secondary" >Create Admin +</a>
                    <?php include 'include/hotbar.php' ?><a href="create_user.php" class="btn btn-secondary" >Create User +</a>
                    <?php include 'include/hotbar.php' ?><a href="user_support.php" class="btn btn-secondary" >User Support</a>
                    <?php include 'include/hotbar.php' ?> <a href="ban_users.php" class="btn btn-secondary" >Banned Users</a>
                </div>

                <h2>Listings</h2>
				<div class="row mt-4">
				<table class="table m-3 rounded bg-light shadow-lg" id="id" id="title" id="description" id="starting_price"id="end_time" id="seller_id"  class="table table-striped" style="width:105%">
					<thead class="thead-dark">
						<tr>
						<th scope="col">ID:</th>
						<th scope="col">Title:</th>
						<th scope="col">Description:</th>
						<th scope="col">Starting Price:</th>
						<th scope="col">End Time:</th>
                        <th scope="col">Seller ID:</th>
						<th style="text-align:right" scope="col" class="text-center">Actions:</th>
						</tr>
					</thead>
					<tbody>
					<?php while ($row = $result->fetch()) { ?>
						<tr>
						<td><?php echo $row['id']; ?></td>
						<td><?php echo $row['title']; ?></td>
						<td><?php echo $row['description']; ?></td>
						<td><?php echo $row['starting_price']; ?></td>
						<td><?php echo $row['end_time']; ?></td>
                        <td><?php echo $row['seller_id']; ?></td>
						<td class="text-center">
             
						<td style="text-align:left" class="text-center">
						<a href="edit_listing.php?id=<?php echo $row['id']; ?>" class="btn btn-sm">
							<svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="currentColor" class="bi bi-pencil-square" viewBox="0 0 16 16">
							<path d="M15.502 1.94a.5.5 0 0 1 0 .706L14.459 3.69l-2-2L13.502.646a.5.5 0 0 1 .707 0l1.293 1.293zm-1.75 2.456-2-2L4.939 9.21a.5.5 0 0 0-.121.196l-.805 2.414a.25.25 0 0 0 .316.316l2.414-.805a.5.5 0 0 0 .196-.12l6.813-6.814z"></path>
							<path fill-rule="evenodd" d="M1 13.5A1.5 1.5 0 0 0 2.5 15h11a1.5 1.5 0 0 0 1.5-1.5v-6a.5.5 0 0 0-1 0v6a.5.5 0 0 1-.5.5h-11a.5.5 0 0 1-.5-.5v-11a.5.5 0 0 1 .5-.5H9a.5.5 0 0 0 0-1H2.5A1.5 1.5 0 0 0 1 2.5v11z"></path>
							</svg>
						</a>

						<a href="delete_listing.php?id=<?php echo $row['id']; ?>" class="btn btn-sm">
							<svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="currentColor" class="bi bi-trash" viewBox="0 0 16 16">
							<path d="M5.5 5.5A.5.5 0 0 1 6 6v6a.5.5 0 0 1-1 0V6a.5.5 0 0 1 .5-.5zm2.5 0a.5.5 0 0 1 .5.5v6a.5.5 0 0 1-1 0V6a.5.5 0 0 1 .5-.5zm3 .5a.5.5 0 0 0-1 0v6a.5.5 0 0 0 1 0V6z"></path>
							<path fill-rule="evenodd" d="M14.5 3a1 1 0 0 1-1 1H13v9a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2V4h-.5a1 1 0 0 1-1-1V2a1 1 0 0 1 1-1H6a1 1 0 0 1 1-1h2a1 1 0 0 1 1 1h3.5a1 1 0 0 1 1 1v1zM4.118 4 4 4.059V13a1 1 0 0 0 1 1h6a1 1 0 0 0 1-1V4.059L11.882 4H4.118zM2.5 3V2h11v1h-11z"></path>
						</svg>
						</a>

						</td>
						</tr>
					<?php } ?>
					</tbody>
				</table>
				</div>
			</div>
		</section>
	</div>
<br><br><br><br>
<footer>
    <?php include 'include/footer.php';?>  
</footer>
<script>
  $(document).ready(function () {
    $('#id').DataTable();
});
    </script>
    <footer>
    <?php include 'include/footer.php';?>  
</footer>
</body>
</html>