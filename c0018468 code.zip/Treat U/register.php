<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Create An Account</title>
    <?php include 'include/style.php'; ?>
    <script src="https://smtpjs.com/v3/smtp.js"></script>
</head>
<body>
    <div class="container">
        <h1>Create An Account</h1>
        <?php
        // Start the session
        session_start();

        include_once 'connection.php';

        // Include the PHPMailer library
        require 'vendor\autoload.php';
        require 'vendor\phpmailer\phpmailer\src\Exception.php';
        require 'vendor\phpmailer\phpmailer\src\PHPMailer.php';
        require 'vendor\phpmailer\phpmailer\src\SMTP.php';

        use PHPMailer\PHPMailer\PHPMailer;
        use PHPMailer\PHPMailer\SMTP;
        use PHPMailer\PHPMailer\Exception;
        use PHPMailer\PHPMailer\OAuth;
        use PHPMailer\PHPMailer\autoload;

            // Check if the form is submitted
            if ($_SERVER['REQUEST_METHOD'] === 'POST') {
            // Get the form data
            $first_name = $_POST['first_name'];
            $last_name = $_POST['last_name'];
            $email = $_POST['email'];
            $phone_number = $_POST['phone_number'];

            // Generate a verification code
            $verification_code = generateVerificationCode();

            // Insert user data into the 'users' table
            $insert_query = "INSERT INTO users (first_name, last_name, email, phone_number, verification_code) VALUES (:first_name, :last_name, :email, :phone_number, :verification_code)";
            $stmt = $connection->prepare($insert_query);
            $stmt->bindParam(':first_name', $first_name);
            $stmt->bindParam(':last_name', $last_name);
            $stmt->bindParam(':email', $email);
            $stmt->bindParam(':phone_number', $phone_number);
            $stmt->bindParam(':verification_code', $verification_code);
            $stmt->execute();
            
        
            // Send verification email to the user
            sendEmail($email, $verification_code);
            exit;
        }

        // Helper function to generate a random verification code
        function generateVerificationCode()
        {
            return substr(md5(uniqid(rand(), true)), 0, 6);
        }

        function sendEmail($email, $verification_code)
        {
            $mail = new PHPMailer;
            $mail->isSMTP();
            //$mail->SMTPDebug = SMTP::DEBUG_SERVER;  // Enable verbose debug output
            //$mail->Debugoutput = function ($str, $level) {
            // echo "Debug level $level; message: $str\n";
           // };

            $mail->Host = 'smtp.gmail.com';
            $mail->SMTPSecure = 'tls';
            $mail->SMTPAutoTLS = false;
            $mail->Port = 587;
            $mail->SMTPAuth = true;
            $mail->Username = 'ptusermail@gmail.com';
            $mail->Password = 'yxemzojcldqqblyx';

            $mail->setFrom('ptusermail@gmail.com');
            $mail->addAddress($email);
            $mail->Subject = 'Treat U';
            $mail->Body = 'OTP: ' . $verification_code;

            if ($mail->send()) {
                echo 'An OTP has been sent to your email address. Please check your inbox.';
                echo '<p><a href="login.php">Login to your account</a></p>';
            } else {
                echo 'Email could not be sent. Please try again.';
                //echo 'Mailer Error: ' . $mail->ErrorInfo;
                echo '<p><a href="register.php">Register</a></p>';
            }
        }
         ?>

        <form method="post" action="register.php" onsubmit="sendEmail(); reset(); return false;">
            <label for="first-name">First Name</label>
            <input type="text" id="first-name" name="first_name" required>

            <label for="last-name">Last Name</label>
            <input type="text" id="last-name" name="last_name" required>

            <label for="email">Email Address</label>
            <input type="text" id="email" name="email" required>

            <label for="phone_number">Phone Number</label>
            <input type="text" id="phone_number" name="phone_number" required>

            <p><input type="submit" value="Sign Up"></p>
        </form>

        <p>Already have an account? <a href="login.php">Sign in now</a>.</p>
    </div>
    <footer>
        <?php include 'include/footer.php'; ?>  
    </footer>
</body>
</html>
