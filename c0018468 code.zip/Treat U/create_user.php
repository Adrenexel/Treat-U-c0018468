

<!DOCTYPE html>
<?php 
//starting the session
session_start();
require_once 'connection.php';
$result = $connection->query("SELECT * FROM users");
?>
<head>
    <meta charset="utf-8">
    <?php include 'include/style.php';?>
    <?php include 'include/nav.php';?>
    <script src="https://smtpjs.com/v3/smtp.js"></script>
    <title>Create User</title>
<html>
<body>

	<div class="container">	
		<section class="py-5 header">
			<div class="container py-4">
				<div class="row">
					<div class="col-md-12 text-center">
						<h3>Create User</h3>
					</div>
				</div>
				<div class="wrapper fadeInDown">
					<div id="formContent">
						<?php if(isset($_GET['msg'])) { ?>
						<div class="alert alert-danger alert-dismissible mt-4 mb-2 fade show" role="alert">
							<strong class="px-2">Error:</strong> <?php echo $_GET['msg']; ?>
							<button type="button" class="close" data-dismiss="alert" aria-label="Close">
								<span aria-hidden="true">&times;</span>
							</button>
						</div>
						<?php } ?>
						<form method="post" action="create_user_q.php" onsubmit="sendEmail(); reset(); return false;">
							<div class="form-row">
									<label for="inputEmail4">First Name</label>
									<input type="text" class="form-control" name="first_name" placeholder="First Name" required>
									<label for="inputEmail4">Last Name</label>
									<input type="text" class="form-control" name="last_name" placeholder="Last Name" required>
									<label for="inputEmail4">Email</label>
									<input type="text" class="form-control" name="email" placeholder="Email" required>
									<label for="inputEmail4">Phone_number</label>
									<input type="text" class="form-control" name="phone_number" placeholder="Phone Number" required>
							</div>
                            <button type="submit" name="register" class="btn btn-primary">Create User</button>
						</form>
					</div>
				</div>
			</div>
		</section>
	</div>

    <a href = admin.php >Back to Profile</a>


<footer>
    <?php include 'include/footer.php';?>  
</footer>

</body>
</html>